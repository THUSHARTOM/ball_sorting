import cv2
from inference import inference
import time
import numpy as np
cap = cv2.VideoCapture('/home/hrishi/FMS/ds/test_videos/thushar ball 1.mp4')
count = 0
font = cv2.FONT_HERSHEY_SIMPLEX
fontScale = 1
color = (255, 0, 0)
thickness = 1
class_names = ['blue', 'orange','empty']

def resize(im):
    im = cv2.resize(im,(52,52),interpolation=cv2.INTER_NEAREST)
    im = im[None,...]
    return im
def put_text(img,pos,class_name):
    print(type(class_name))
    img = cv2.putText(img,class_name, pos, font,fontScale, color, thickness, cv2.LINE_AA)
    return img


while(cap.isOpened()):
    start_time = time.time()
    ret, frame = cap.read()
    if ret == True:
        input = cv2.cvtColor(frame,cv2.COLOR_BGR2RGB)
        loc_1,loc_2,loc_3,loc_4 = input[196:286,232:358,:],input[185:294,476:649,:],input[210:359,736:900,:],input[386:493,977:1202,:]
        loc_1,loc_2,loc_3,loc_4 = resize(loc_1),resize(loc_2),resize(loc_3),resize(loc_4)
        input = np.concatenate([loc_1,loc_2,loc_3,loc_4],axis=0)
        io_time = time.time()-start_time
        # print(f'Time for IO operations = {io_time}')
        final_pred = inference(input)
        frame = put_text(frame,(232,196),class_names[final_pred[0]])
        frame = put_text(frame,(476,185),class_names[final_pred[1]])
        frame = put_text(frame,(736,210),class_names[final_pred[2]])
        frame = put_text(frame,(977,386),class_names[final_pred[3]])
        print(f'Time for Inference operation = {(time.time()-start_time)-io_time}')
        cv2.imshow('Frame',frame)
        cv2.waitKey(100)
    else:
        break

cap.release()
cv2.destroyAllWindows
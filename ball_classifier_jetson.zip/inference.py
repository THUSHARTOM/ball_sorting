import tensorflow as tf
import numpy as np

trained_model = tf.keras.models.load_model('./saved_model_fp16')
class_names = ['blue', 'orange','empty']
def inference(input_frame):
    input_im = input_frame/255.0
    # input_im = tf.cast(tf.expand_dims(input_im, 0),tf.float32)
    input_im = tf.cast(input_im,tf.float32)
    predictions = trained_model(input_im)
    score = tf.nn.softmax(predictions)
    final_pred = tf.where(tf.reduce_max(score,axis=1)>0.98,tf.argmax(score,axis=1),2)
    return final_pred